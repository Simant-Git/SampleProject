export class Customer {
    id: number;
    name: string;
    dateOfBirth: string;
    email: string;
    password: string;
    profilePic: string;
}
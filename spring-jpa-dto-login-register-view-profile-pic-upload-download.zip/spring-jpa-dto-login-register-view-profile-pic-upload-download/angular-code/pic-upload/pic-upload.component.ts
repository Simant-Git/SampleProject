import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-pic-upload',
  templateUrl: './pic-upload.component.html',
  styleUrls: ['./pic-upload.component.css']
})
export class PicUploadComponent implements OnInit {

  profilePic: any;
  customerId : any;

  constructor(private customerService: CustomerService) { }

  ngOnInit(): void {
    this.customerId = sessionStorage.getItem('customerId');
  }

  onFileChange(event){
    this.profilePic = event.target.files[0];
  }

  upload() {
    let formData: FormData = new FormData();
    formData.append('customerId', this.customerId);
    formData.append('profilePic', this.profilePic);
    console.log(formData.get('profilePic'));
  
    this.customerService.upload(formData).subscribe(data => {
      alert(JSON.stringify(data));
    })
  }

}

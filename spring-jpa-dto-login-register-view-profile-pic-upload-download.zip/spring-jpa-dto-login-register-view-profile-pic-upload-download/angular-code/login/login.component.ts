import { Component, OnInit } from '@angular/core';
import { Login } from '../login';
import { LoginService } from '../login.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {

  login: Login = new Login();
  message: string;

  constructor(private loginService: LoginService, private router: Router) { }

  loginUser() {
    alert(JSON.stringify(this.login));
    this.loginService.login(this.login).subscribe(data => {
      alert(JSON.stringify(data));
      if(data.status == 'SUCCESS') {
        let customerId = data.customerId;
        let customerName = data.name;
        //let obj = {id : customerId, name : customerName};
        sessionStorage.setItem('customerId', String(customerId));
        sessionStorage.setItem('customerName', customerName);
        this.router.navigate(['dashboard']);
      }
      else {
        this.message = data.message;
      }
    })
  }

}

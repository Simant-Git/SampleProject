import { Component, OnInit } from '@angular/core';
import { Customer } from '../customer';
import { Router } from '@angular/router';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {

  customer: Customer = new Customer();

  constructor(private customerService: CustomerService, private router: Router) { }

  register() {
    //alert(JSON.stringify(this.customer));
    this.customerService.register(this.customer).subscribe(data => {
      //alert(JSON.stringify(data));
      if(data.status == 'SUCCESS') {
        this.router.navigate(['thankyou'])
      }
      else {
        //missing code right now
      }
    })
  }

}

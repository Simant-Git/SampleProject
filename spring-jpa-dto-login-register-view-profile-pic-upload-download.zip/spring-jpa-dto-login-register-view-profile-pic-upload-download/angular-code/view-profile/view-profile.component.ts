import { Customer } from './../customer';
import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-view-profile',
  templateUrl: './view-profile.component.html',
  styleUrls: ['./view-profile.component.css']
})
export class ViewProfileComponent implements OnInit {

  customerId: any;
  customer: Customer;

  constructor(private customerService: CustomerService) { 
    this.customerId = sessionStorage.getItem('customerId');
  }

  ngOnInit(): void {
    this.customerService.fetchProfile(this.customerId).subscribe(data => {
      this.customer = data;
      alert(JSON.stringify(this.customer));
    })
  }

}

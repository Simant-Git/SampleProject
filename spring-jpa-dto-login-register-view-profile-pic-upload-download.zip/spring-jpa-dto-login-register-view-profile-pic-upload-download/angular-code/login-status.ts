export class LoginStatus {
   status: string;
   message: string;
   customerId: number;
   name: string;
    
}
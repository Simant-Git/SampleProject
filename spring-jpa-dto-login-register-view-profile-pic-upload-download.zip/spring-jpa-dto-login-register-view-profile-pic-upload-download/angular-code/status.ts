export class Status {
    status: string;
    message: string;
}
import { Status } from './status';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'; 
import { Customer } from './customer';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  constructor(private http: HttpClient) { }

  register(customer: Customer) : Observable<Status> {
    let url = 'http://localhost:8585/register';
    return this.http.post<Status>(url, customer);
  }

  upload(formData: FormData) {
    let url='http://localhost:8585/pic-upload';
    return this.http.post(url, formData);
  }

  fetchProfile(customerId: number) : Observable<Customer> {
    let url='http://localhost:8585/profile?customerId='+customerId;
    return this.http.get<Customer>(url);
  }


}

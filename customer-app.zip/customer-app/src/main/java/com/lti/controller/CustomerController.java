package com.lti.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.lti.dto.LoginDto;
import com.lti.dto.LoginStatus;
import com.lti.dto.ProfilePicDto;
import com.lti.dto.Status;
import com.lti.dto.Status.StatusType;
import com.lti.entity.Customer;
import com.lti.exception.CustomerServiceException;
import com.lti.service.CustomerService;

@RestController
@CrossOrigin
public class CustomerController {

	@Autowired
	private CustomerService customerService;
	
	// http://localhost:8585/CustomerApp
	//@RequestMapping(path = .., method = POST, ...)
		@PostMapping(path = "/register")
		public Status register(@RequestBody Customer customer) {
			try {
				customerService.register(customer);
				
				Status status = new Status();
				status.setStatus(StatusType.SUCCESS);
				status.setMessage("Registration successful!");
				return status;
			}
			catch(CustomerServiceException e) {
				Status status = new Status();
				status.setStatus(StatusType.FAILURE);
				status.setMessage(e.getMessage());
				return status;
			}
		}
		
		@PostMapping("/pic-upload")
		public Status upload(ProfilePicDto profilePicDto) {
			String imageUploadLocation = "d:/uploads/";
			String fileName = profilePicDto.getProfilePic().getOriginalFilename();
			String targetFile = imageUploadLocation + fileName;
			try {
				FileCopyUtils.copy(profilePicDto.getProfilePic().getInputStream(), new FileOutputStream(targetFile));
			} catch (IOException e) {
				e.printStackTrace();
				Status status = new Status();
				status.setStatus(StatusType.FAILURE);
				status.setMessage(e.getMessage());
				return status;
			}
			Customer customer = customerService.get(profilePicDto.getCustomerId());
			customer.setProfilePic(fileName);
			customerService.update(customer);
			
			Status status = new Status();
			status.setStatus(StatusType.SUCCESS);
			status.setMessage("Uploaded!");
			return status;
		}
		
		@PostMapping("/login")
		public LoginStatus login(@RequestBody LoginDto loginDto) {
			try {
				Customer customer = customerService.login(loginDto.getEmail(), loginDto.getPassword());
				LoginStatus loginStatus = new LoginStatus();
				loginStatus.setStatus(StatusType.SUCCESS);
				loginStatus.setMessage("Login Successful!");
				loginStatus.setCustomerId(customer.getId());
				loginStatus.setName(customer.getName());
				return loginStatus;
			}
			catch(CustomerServiceException e) {
				LoginStatus loginStatus = new LoginStatus();
				loginStatus.setStatus(StatusType.FAILURE);
				loginStatus.setMessage(e.getMessage());
				return loginStatus;
			}
		}
		
		@GetMapping("/profile")
		public Customer profile(@RequestParam("customerId") int id, HttpServletRequest request) {
			//fetching customer data from the database
			Customer customer = customerService.get(id);

			//reading the project's deployed folder location
			String projPath = request.getServletContext().getRealPath("/");
			String tempDownloadPath = projPath + "/downloads/";
			//creating a folder within the project where we will place the profile pic of the customer getting fetched
			File f = new File(tempDownloadPath);
			if(!f.exists())
				f.mkdir();
			String targetFile = tempDownloadPath + customer.getProfilePic();
			
			//the original location where the uploaded images are present
			String uploadedImagesPath = "d:/uploads/";
			String sourceFile = uploadedImagesPath + customer.getProfilePic();
			
			try {
				FileCopyUtils.copy(new File(sourceFile), new File(targetFile));
			} catch (IOException e) {
				e.printStackTrace();
				//maybe for this customer there is no profile pic
			}
			
			return customer;
		}
		
}







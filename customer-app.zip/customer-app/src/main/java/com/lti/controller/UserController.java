package com.lti.controller;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.lti.dto.UserDto;
import com.lti.entity.User;
import com.lti.service.UserService;

@RestController
public class UserController {

	@Autowired
	UserService service;
	
	@PostMapping(value = "/addUser")
	public User addOrUpdateUser(@RequestBody UserDto userDto) {
		User user=new User();
		user.setUserName(userDto.getUserName());
		user.setEmail(userDto.getEmail());
		user.setPassword(userDto.getPassword());
		user.setDateOfBirth(LocalDate.parse(userDto.getDateOfBirth()));
		user.setPhone(userDto.getPhone());
		
		return service.addAUser(user);
	}
}

package com.lti.repository;

import java.util.List;

import com.lti.entity.Customer;

public interface CustomerRepository {

	int save(Customer customer);

	Customer findById(int id);

	List<Customer> findAll();

	int findByEmailAndPassword(String email, String password);

	boolean isCustomerPresent(String email);
}

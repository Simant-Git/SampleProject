package com.lti.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.lti.entity.User;

public interface UserDataRepository extends JpaRepository<User,Integer> {
	User getByEmail(String email);
	User getByPhone(String phone);
}

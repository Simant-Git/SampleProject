package com.lti.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.lti.entity.Customer;

@Repository
public class CustomerRepositoryImpl implements CustomerRepository {

	@PersistenceContext
	EntityManager em;
	
	@Override
	@Transactional
	public int save(Customer customer) {
		Customer c=em.merge(customer);
		return c.getId();
	}

	@Override
	public Customer findById(int id) {
		return em.find(Customer.class, id);
	}

	@Override
	public List<Customer> findAll() {
		return em.createNamedQuery("fetch-all")
				 .getResultList();
	}

	@Override
	public int findByEmailAndPassword(String email, String password) {
		return (Integer) em
				.createQuery("select c.id from Customer c where c.email = :em and c.password = :pw")
				.setParameter("em", email)
				.setParameter("pw", password)
				.getSingleResult();
	}

	@Override
	public boolean isCustomerPresent(String email) {
		return (Long)
				em
				.createQuery("select count(c.id) from Customer c where c.email = :em")
				.setParameter("em", email)
				.getSingleResult() == 1 ? true : false;
	}

}

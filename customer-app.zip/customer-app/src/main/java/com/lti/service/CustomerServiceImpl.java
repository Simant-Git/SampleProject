package com.lti.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;

import com.lti.entity.Customer;
import com.lti.exception.CustomerServiceException;
import com.lti.repository.CustomerRepository;
import com.lti.repository.CustomerRepositoryImpl;

@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	private CustomerRepository customerRepo;
	@Autowired
	private EmailService emailService;
	@Override
	public void register(Customer customer) {
		if(!customerRepo.isCustomerPresent(customer.getEmail())) {
			int id=customerRepo.save(customer);
			String text="Successfully registered. Your id is "+id;
			String subject="Registration Confirmation";
			emailService.sendEmailForNewRegistration(customer.getEmail(), text, subject);
		}
		else
			throw new CustomerServiceException("Customer already registered!");
	}

	@Override
	public Customer login(String email, String password) {
		try {
			if(!customerRepo.isCustomerPresent(email))
				throw new CustomerServiceException("Customer not registered!");
			int id = customerRepo.findByEmailAndPassword(email, password);
			Customer customer = customerRepo.findById(id);
			return customer;
		}
		catch(EmptyResultDataAccessException e) {
			throw new CustomerServiceException("Incorrect email/password");
		}
	}

	@Override
	public Customer get(int id) {
		return customerRepo.findById(id);
	}

	@Override
	public void update(Customer customer) {
		customerRepo.save(customer);
	}

}

package com.lti.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.lti.entity.User;
import com.lti.repository.UserDataRepository;

@Component
public class UserService {

	@Autowired
	UserDataRepository repository;
	
	public User addAUser(User user) {
		User persistedUser=repository.save(user);
		return persistedUser;
	}
	
	public User getUserById(int userId) {
		return repository.getById(userId);
	}
	
	public List<User> viewAllUsers(){
		return repository.findAll();
	}
	
	public User getUserByEmail(String email) {
		return repository.getByEmail(email);
	}
	
	public User getUserByPhone(String phone) {
		return repository.getByPhone(phone);
	}
}

package com.lti;

import java.time.LocalDate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.lti.entity.User;
import com.lti.service.UserService;

@SpringBootTest
class CustomerAppApplicationTests {

	@Test
	void testJpa() {
		
	}

}
